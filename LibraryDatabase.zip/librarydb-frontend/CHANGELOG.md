## [0.0.3] - 2026-01-11
### Added
- Working Settings page (color schemes + dark mode + books-per-line).
- Working Support page (contact info, links, version display, two people cards).
- Theme persistence via localStorage.
### Changed
- UI colors now driven by CSS variables so all schemes work in light and dark mode.
- Book grid supports 3–10 columns (desktop) with auto-scaling cards.
